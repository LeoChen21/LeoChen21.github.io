This is a directory containing scripts that I use daily for repetitive tasks:

hardware: linux (wsl), Ubuntu

In order to make these scripts executable on in any part of the system, follow the procedure below:
1. In the ~/.bashrc file, add the line "export PATH="$PATH:/path/to/Scripts"" to the end of the file
2. Run source ~/.bashrc to enable the new path settings
